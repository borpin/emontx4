# Manufacture Instructions 

* 1.6mm thick PCB
* 2 layers 
* Lead free finish 
* Blue Solder Resist
* No silkscreen should overlap pads

glyn.hudson@openenergymonitor.org
01286800870
